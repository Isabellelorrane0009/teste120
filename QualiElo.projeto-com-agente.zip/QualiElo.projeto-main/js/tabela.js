document.addEventListener('DOMContentLoaded', function () {
    const tabela = document.getElementById('tabelaRegistros');

    if (!tabela) {
        return;
    }

    const registros = JSON.parse(localStorage.getItem('errosRegistrados') || '[]');

    function formatDate(dateString) {
        const meses = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
        const date = new Date(dateString);
        if (Number.isNaN(date.getTime())) {
            return dateString;
        }
        const dia = String(date.getDate()).padStart(2, '0');
        const mes = meses[date.getMonth()];
        const ano = date.getFullYear();
        return `${dia} ${mes} ${ano}`;
    }

    function getBadgeClass(gravidade) {
        if (gravidade.toLowerCase() === 'grave') {
            return 'danger';
        }
        if (gravidade.toLowerCase() === 'médio' || gravidade.toLowerCase() === 'medio') {
            return 'warning';
        }
        return 'success';
    }

    function createTableRow(registro) {
        const linha = document.createElement('tr');
        linha.innerHTML = `
            <td class="date">${formatDate(registro.data)}</td>
            <td>${registro.colaborador}</td>
            <td>${registro.tipo}</td>
            <td>
                <span class="badge ${getBadgeClass(registro.gravidade)}">
                    ${registro.gravidade}
                </span>
            </td>
            <td class="desc">${registro.descricao}</td>
        `;
        return linha;
    }

    // Preencher tabela com registros iniciais
    registros.forEach(function (registro) {
        tabela.appendChild(createTableRow(registro));
    });

    // Canal de broadcast para ouvir novos erros
    const channel = new BroadcastChannel('erros-registrados-channel');

    channel.onmessage = function (event) {
        if (event.data.type === 'NOVO_ERRO_REGISTRADO') {
            const novoRegistro = event.data.registro;
            // Adicionar nova linha no início da tabela
            tabela.insertBefore(createTableRow(novoRegistro), tabela.firstChild);
        }
    };

    // Fechar o canal ao descarregar a página
    window.addEventListener('beforeunload', function () {
        channel.close();
    });
});
