document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');

    const users = {
        gerente: {
            password: 'gerente123',
            path: 'GERENTE/dashbord.html'
        },
        inspetor: {
            password: 'inspetor123',
            path: 'INSPETOR/dashbord-inspetor.html'
        },
        lider: {
            password: 'lider123',
            path: 'LIDER/dashbord-lider.html'
        }
    };

    form.addEventListener('submit', function (e) {
        e.preventDefault();

        const username = usernameInput.value.trim().toLowerCase();
        const password = passwordInput.value;

        if (!username || !password) {
            alert('Preencha usuário e senha.');
            return;
        }

        const user = users[username];

        if (!user || user.password !== password) {
            alert('Usuário ou senha inválidos.');
            return;
        }

        window.location.href = user.path;
    });
});
