document.addEventListener('DOMContentLoaded', function () {
    const gravidadeButtons = document.querySelectorAll('.gravidade-btn');
    const form = document.querySelector('form');
    const colaboradorInput = document.getElementById('colaborador');
    const dataInput = document.getElementById('dataErro');
    const tipoInput = document.getElementById('tipoErro');
    const descricaoInput = document.getElementById('descricao');
    const recentTitle = document.querySelector('.recent-item h4');
    const recentUser = document.querySelector('.recent-user');
    const recentTime = document.querySelector('.recent-time');

    let gravidadeSelecionada = 'Simples';

    function updateActiveGravity(button) {
        gravidadeButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        gravidadeSelecionada = button.textContent.trim();
    }

    gravidadeButtons.forEach(button => {
        button.addEventListener('click', function (e) {
            e.preventDefault();
            updateActiveGravity(this);
        });
    });

    if (gravidadeButtons.length > 0) {
        updateActiveGravity(gravidadeButtons[0]);
    }

    function getStoredRegistros() {
        return JSON.parse(localStorage.getItem('errosRegistrados') || '[]');
    }

    function saveStoredRegistros(registros) {
        localStorage.setItem('errosRegistrados', JSON.stringify(registros));
    }

    function formatTime(date) {
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        return `${hours}:${minutes}`;
    }

    function updateRecentCard(registro) {
        if (!recentTitle || !recentUser || !recentTime) {
            return;
        }

        recentTitle.textContent = registro.tipo;
        recentUser.innerHTML = `<span class="dot"></span>${registro.colaborador}`;
        recentTime.textContent = formatTime(new Date());
    }

    // Canal de broadcast para comunicação entre abas
    const channel = new BroadcastChannel('erros-registrados-channel');

    form.addEventListener('submit', function (event) {
        event.preventDefault();

        const colaborador = colaboradorInput.value.trim();
        const data = dataInput.value;
        const tipo = tipoInput.value.trim();
        const descricao = descricaoInput.value.trim();

        if (!colaborador || !data || !tipo || !descricao) {
            alert('Preencha todos os campos antes de registrar o erro.');
            return;
        }

        const registro = {
            id: Date.now(),
            colaborador,
            data,
            tipo,
            gravidade: gravidadeSelecionada,
            descricao
        };

        const registros = getStoredRegistros();
        registros.unshift(registro);
        saveStoredRegistros(registros);

        // Enviar evento de broadcast para atualizar dashboards
        channel.postMessage({
            type: 'NOVO_ERRO_REGISTRADO',
            registro: registro
        });

        updateRecentCard(registro);

        tipoInput.value = '';
        descricaoInput.value = '';
        alert('Erro registrado com sucesso!');
    });

    // Fechar o canal ao descarregar a página
    window.addEventListener('beforeunload', function () {
        channel.close();
    });
});
