document.addEventListener('DOMContentLoaded', function () {
    // Seleciona todos os links do menu
    const links = document.querySelectorAll('.nav-link');

    links.forEach(link => {
      link.addEventListener('click', function () {
        // Remove a classe 'active' do item que estava selecionado antes
        document.querySelector('.nav-link.active')?.classList.remove('active');

        // Adiciona a classe 'active' apenas no item que acabou de ser clicado
        this.classList.add('active');
      });
    });

    const topErrorTitle = document.getElementById('erroMaisFrequente');
    const topErrorCount = document.getElementById('erroMaisFrequenteCount');

    function updateTopError() {
        if (topErrorTitle && topErrorCount) {
            const registros = JSON.parse(localStorage.getItem('errosRegistrados') || '[]');
            if (registros.length === 0) {
                topErrorTitle.textContent = 'Nenhum erro registrado';
                topErrorCount.textContent = '0 ocorrências';
            } else {
                const frequencia = registros.reduce((acc, registro) => {
                    const tipo = registro.tipo ? registro.tipo.trim() : '';
                    if (!tipo) return acc;
                    acc[tipo] = (acc[tipo] || 0) + 1;
                    return acc;
                }, {});

                const top = Object.entries(frequencia).sort((a, b) => b[1] - a[1])[0];

                if (top) {
                    const [tipo, count] = top;
                    topErrorTitle.textContent = tipo;
                    topErrorCount.textContent = `${count} ${count === 1 ? 'ocorrência' : 'ocorrências'}`;
                }
            }
        }
    }

    // Atualizar na primeira carga
    updateTopError();

    // Canal de broadcast para ouvir novos erros
    const channel = new BroadcastChannel('erros-registrados-channel');

    channel.onmessage = function (event) {
        if (event.data.type === 'NOVO_ERRO_REGISTRADO') {
            // Atualizar o card de erro mais frequente em tempo real
            updateTopError();
        }
    };

    // Fechar o canal ao descarregar a página
    window.addEventListener('beforeunload', function () {
        channel.close();
    });
});
