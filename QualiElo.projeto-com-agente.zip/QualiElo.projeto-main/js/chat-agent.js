/* Assistente de Treinamentos
 * Agente client-side que segue o System Prompt:
 *  - Uma pergunta por vez, com validação
 *  - Coleta: motivo, e-mail, quantidade, data/hora
 *  - Aciona "create_calendar_event" abrindo o Google Calendar pré-preenchido
 */
(function () {
  const STEPS = [
    {
      key: "motivo",
      question: "Olá! Sou o Assistente de Treinamentos. Para começar, qual é o tema ou motivo principal do treinamento?",
      validate: (v) => {
        v = (v || "").trim();
        if (v.length < 3) return { ok: false, msg: "Poderia descrever o motivo com pelo menos 3 caracteres?" };
        return { ok: true, value: v };
      },
    },
    {
      key: "email",
      question: "Perfeito. Qual o seu e-mail de contato?",
      validate: (v) => {
        v = (v || "").trim();
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!re.test(v)) return { ok: false, msg: "Esse e-mail parece incompleto. Poderia confirmar no formato nome@dominio.com?" };
        return { ok: true, value: v };
      },
    },
    {
      key: "quantidade",
      question: "Quantas pessoas irão participar do treinamento?",
      validate: (v) => {
        v = (v || "").trim();
        if (!/^\d+$/.test(v)) return { ok: false, msg: "Preciso de um número inteiro de participantes (ex.: 1, 5, 12). Pode informar novamente?" };
        const n = parseInt(v, 10);
        if (n < 1) return { ok: false, msg: "A quantidade deve ser de pelo menos 1 participante." };
        return { ok: true, value: n };
      },
    },
    {
      key: "dataHora",
      question: "Para qual dia e horário você gostaria de agendar? (ex.: 25/12/2026 às 14:00)",
      validate: (v) => parseDateTime(v),
    },
  ];

  function parseDateTime(input) {
    if (!input) return { ok: false, msg: "Informe a data e a hora (ex.: 25/12/2026 às 14:00)." };
    const s = input.trim().toLowerCase().replace(" as ", " ").replace(" às ", " ").replace(/h(\d{2})?/, ":$1").replace(/\s+/g, " ");
    // Tenta DD/MM/AAAA HH:MM  ou  DD/MM HH:MM
    const m = s.match(/^(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?\s+(\d{1,2})(?::(\d{2}))?$/);
    if (!m) return { ok: false, msg: "Não entendi a data. Use o formato DD/MM/AAAA às HH:MM (ex.: 25/12/2026 às 14:00)." };
    let [, dd, mm, yyyy, hh, mi] = m;
    const now = new Date();
    let year = yyyy ? parseInt(yyyy, 10) : now.getFullYear();
    if (year < 100) year += 2000;
    const date = new Date(year, parseInt(mm, 10) - 1, parseInt(dd, 10), parseInt(hh, 10), parseInt(mi || "0", 10), 0);
    if (isNaN(date.getTime())) return { ok: false, msg: "Data inválida. Tente novamente no formato DD/MM/AAAA às HH:MM." };
    if (date.getTime() < now.getTime()) {
      // Se sem ano e já passou, adianta um ano
      if (!yyyy) date.setFullYear(date.getFullYear() + 1);
      else return { ok: false, msg: "Essa data já passou. Escolha uma data futura." };
    }
    return { ok: true, value: date };
  }

  function toISOWithOffset(date) {
    const pad = (n) => String(n).padStart(2, "0");
    const tz = -date.getTimezoneOffset();
    const sign = tz >= 0 ? "+" : "-";
    const tzH = pad(Math.floor(Math.abs(tz) / 60));
    const tzM = pad(Math.abs(tz) % 60);
    return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}:00${sign}${tzH}:${tzM}`;
  }

  // "Function tool": create_calendar_event -> abre Google Calendar pré-preenchido
  function createCalendarEvent({ title, description, start_time, attendees }) {
    try {
      const start = new Date(start_time);
      const end = new Date(start.getTime() + 60 * 60 * 1000); // +1h
      const fmt = (d) => d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
      const url = "https://calendar.google.com/calendar/r/eventedit?" + new URLSearchParams({
        text: title,
        details: description,
        dates: `${fmt(start)}/${fmt(end)}`,
        add: attendees.join(","),
      }).toString();
      window.open(url, "_blank", "noopener");
      return { success: true };
    } catch (e) {
      return { success: false, reason: e.message || "unknown" };
    }
  }

  // UI
  function buildUI() {
    if (document.getElementById("chat-agent-overlay")) return;
    const overlay = document.createElement("div");
    overlay.id = "chat-agent-overlay";
    overlay.className = "chat-overlay";
    overlay.innerHTML = `
      <div class="chat-window" role="dialog" aria-label="Assistente de Treinamentos">
        <div class="chat-header">
          <div class="avatar"><i class="bi bi-robot"></i></div>
          <div class="meta">
            <strong>Assistente de Treinamentos</strong>
            <small>Online · responde em segundos</small>
          </div>
          <button class="close" aria-label="Fechar">&times;</button>
        </div>
        <div class="chat-body" id="chat-agent-body"></div>
        <form class="chat-footer" id="chat-agent-form" autocomplete="off">
          <input type="text" id="chat-agent-input" placeholder="Digite sua resposta..." autocomplete="off" />
          <button type="submit">Enviar</button>
        </form>
      </div>`;
    document.body.appendChild(overlay);

    overlay.querySelector(".close").addEventListener("click", closeChat);
    overlay.addEventListener("click", (e) => { if (e.target === overlay) closeChat(); });
    overlay.querySelector("#chat-agent-form").addEventListener("submit", onSubmit);
  }

  const state = { step: 0, data: {}, done: false };

  function openChat() {
    buildUI();
    state.step = 0; state.data = {}; state.done = false;
    document.getElementById("chat-agent-body").innerHTML = "";
    document.getElementById("chat-agent-overlay").classList.add("open");
    setTimeout(() => {
      addBot(STEPS[0].question);
      document.getElementById("chat-agent-input").focus();
    }, 150);
  }
  function closeChat() {
    const o = document.getElementById("chat-agent-overlay");
    if (o) o.classList.remove("open");
  }

  function addMsg(text, who) {
    const body = document.getElementById("chat-agent-body");
    const d = document.createElement("div");
    d.className = "msg " + who;
    d.textContent = text;
    body.appendChild(d);
    body.scrollTop = body.scrollHeight;
    return d;
  }
  function addBot(text) { return addMsg(text, "bot"); }
  function addUser(text) { return addMsg(text, "user"); }
  function addTool(text) {
    const body = document.getElementById("chat-agent-body");
    const d = document.createElement("div");
    d.className = "msg tool";
    d.textContent = "🔧 " + text;
    body.appendChild(d);
    body.scrollTop = body.scrollHeight;
  }
  function showTyping() {
    const body = document.getElementById("chat-agent-body");
    const d = document.createElement("div");
    d.className = "msg bot";
    d.innerHTML = '<span class="typing"><span></span><span></span><span></span></span>';
    body.appendChild(d);
    body.scrollTop = body.scrollHeight;
    return d;
  }
  function botReply(text, delay = 600) {
    const t = showTyping();
    setTimeout(() => { t.remove(); addBot(text); }, delay);
  }

  function onSubmit(e) {
    e.preventDefault();
    const input = document.getElementById("chat-agent-input");
    const value = input.value;
    if (!value.trim() || state.done) return;
    addUser(value);
    input.value = "";

    const step = STEPS[state.step];
    const result = step.validate(value);
    if (!result.ok) { botReply(result.msg); return; }

    state.data[step.key] = result.value;
    state.step++;

    if (state.step < STEPS.length) {
      botReply(STEPS[state.step].question);
    } else {
      finish();
    }
  }

  function finish() {
    state.done = true;
    const { motivo, email, quantidade, dataHora } = state.data;
    const args = {
      title: `Treinamento: ${motivo}`,
      description: `Treinamento agendado via Assistente IA. Participantes: ${quantidade}. E-mail do organizador: ${email}.`,
      start_time: toISOWithOffset(dataHora),
      attendees: [email],
    };
    const typing = showTyping();
    setTimeout(() => {
      typing.remove();
      addTool(`create_calendar_event(${JSON.stringify(args)})`);
      const r = createCalendarEvent(args);
      const dataFmt = dataHora.toLocaleDateString("pt-BR");
      const horaFmt = dataHora.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
      if (r.success) {
        addBot(`Perfeito! O seu treinamento sobre '${motivo}' foi agendado com sucesso para o dia ${dataFmt} às ${horaFmt}. Um convite foi enviado para o e-mail ${email}.`);
      } else {
        addBot(`Não consegui concluir o agendamento agora (motivo: ${r.reason}). Poderia escolher outra data ou horário?`);
        state.done = false; state.step = STEPS.length - 1;
      }
    }, 800);
  }

  // Liga os botões "Agendar Treinamento"
  function bindButtons() {
    document.querySelectorAll("a, button").forEach((el) => {
      const txt = (el.textContent || "").trim().toLowerCase();
      if (txt.includes("agendar treinamento")) {
        el.addEventListener("click", (e) => {
          e.preventDefault();
          openChat();
        });
      }
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bindButtons);
  } else {
    bindButtons();
  }
})();
